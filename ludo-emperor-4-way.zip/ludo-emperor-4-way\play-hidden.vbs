' Silent launcher for Ludo Emperor 4 Way.
' Starts the game's local server in the background (hidden, no console window)
' and opens the game in the default browser. The server keeps running after
' this script exits, so the link stays valid. Run STOP-Ludo-Emperor.cmd to end it.

Option Explicit

Dim fso, shell, base, server, url, cmd, port
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

base = "C:\Users\Yousuf Traders\Downloads\ludo-emperor-4-way"
server = base & "\Run with local server\serve.mjs"
port = 8080
url = "http://127.0.0.1:" & port & "/"

If Not fso.FileExists(server) Then
    MsgBox "Could not find the game server at:" & vbCrLf & server & vbCrLf & vbCrLf & _
           "Re-extract the zip to that folder, or just double-click" & vbCrLf & _
           "PLAY-Ludo-Emperor.html inside it.", 16, "Ludo Emperor"
    WScript.Quit 1
End If

' node serve.mjs <port>   -- window style 0 = hidden, bWaitOnReturn False
cmd = "cmd /c node """ & server & """ " & port
shell.Run cmd, 0, False

' give the server a moment to bind the port, then open the game
WScript.Sleep 2500
shell.Run url, 1, False
