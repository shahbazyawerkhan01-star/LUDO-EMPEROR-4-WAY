@echo off
rem Ludo Emperor 4 Way - double-click to start the shared web + mobile server.
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
    echo Node.js not found. Just double-click PLAY-Ludo-Emperor.html instead - no Node needed.
    pause
    exit /b 1
)
node "Run with local server\serve.mjs" %*
if errorlevel 1 pause
endlocal
