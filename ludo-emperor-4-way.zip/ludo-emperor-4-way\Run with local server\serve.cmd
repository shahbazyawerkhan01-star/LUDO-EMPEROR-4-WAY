@echo off
rem One-click launcher: serves the multi-file build in the project's dist folder
rem and opens your browser. Phones on the same Wi-Fi can use the address printed
rem in the console (run ALLOW-PHONE-ACCESS.cmd once to let them through the
rem firewall).
rem
rem Prefer the single file PLAY-Ludo-Emperor.html one folder up - it needs none
rem of this.
setlocal

cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
    echo.
    echo   Node.js was not found on this PC.
    echo.
    echo   Easiest fix: go up one folder and double-click
    echo       PLAY-Ludo-Emperor.html
    echo   That version needs no Node.js and no server.
    echo.
    echo   Or install Node.js from https://nodejs.org and try again.
    echo.
    pause
    exit /b 1
)

echo.
echo   Starting Ludo Emperor 4 Way...
echo.
node "serve.mjs" %*

if errorlevel 1 (
    echo.
    echo   The game stopped with an error. See the message above.
    pause
)

endlocal
